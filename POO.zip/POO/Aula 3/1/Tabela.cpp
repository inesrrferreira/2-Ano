//
// Created by inesr on 02/11/2024.
//

#include "Tabela.h"
#include <sstream>
#include <iostream>

using namespace std;

Tabela::Tabela(): tam (0){
    for (int i =0 ; i<limite; i++){
        tab[i]=0;
    }
}

void Tabela::preenche(int num) {
    for (int i = 0; i < limite; i++){
        tab[i] = num;
    }
    tam = limite;
}

void Tabela::mostra() {
    for (int i =0 ; i<limite; i++){
        cout << tab[i] << " ";
    }
}

int &Tabela::atualiza(int indice, int valor){
    if(indice < 0 || indice >limite) throw (0);

    for(int i = 0;i < limite; i++){
        if(i == indice){
            tab[i]=valor;
            break;
        }
    }
    return tab[indice];
}

void Tabela:: preencheCresce(int a, int b){
    tab[0]=a;
    for(int i=1; i<limite; i++){
        tab[i]=tab[i-1]+b;
    }
}

bool Tabela:: verifica (int num){
    for (int i=0; i<limite; i++){
        if(tab[i]==num){
            return true;
        }
    }
    return false;
}

bool Tabela::igual(int a, int b) {
    int contador=0;

    for(int i=0;i<limite; i++){
        if(a==tab[i]){
            contador ++;
        }
        if(b==tab[i]){
            contador ++;
        }
    }

    if(contador >1){
        return true;
    }
    return false;
}
