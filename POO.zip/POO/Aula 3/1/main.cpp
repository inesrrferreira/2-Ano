#include <iostream>
#include "Tabela.h"

using namespace std;

int main() {

    Tabela t;

    try {
        t.mostra();
        t.preenche(5);
        cout << '\n' << "Valor no indice: " << t.atualiza(6, 11) << endl;
        t.mostra();
        t.preencheCresce(1,1);
        cout << '\n';
        t.mostra();
        cout << '\n';
        if(t.verifica(9)){
            cout << "Numero existe" << endl;
        }else {
            cout << "Numero nao existe" << endl;
        }
        if(t.igual(4,55)){
            cout << "O conjunto de numeros existe" << endl;
        }else{
            cout << "O conjunto de numeros NAO existe" << endl;
        }

    } catch (int erro){
        cout << "Indice invalido" << endl;
    }


    return 0;
}
