//
// Created by inesr on 02/11/2024.
//

#ifndef AULA_3_TABELA_H
#define AULA_3_TABELA_H


class Tabela {

    static const int limite = 10;
    int tab[limite];
    int tam;

public:
    Tabela();


    void preenche (int valor);
    void mostra();
    int &atualiza(int indice, int valor);
    void preencheCresce(int a, int b);
    bool verifica (int num);
    bool igual (int a, int b);

};



#endif //AULA_3_TABELA_H
