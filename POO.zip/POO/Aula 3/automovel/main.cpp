#include <iostream>
#include "Automovel.h"

using namespace std;


int main() {

    Automovel a ("AE-00-MD", "Gasoleo", "BMW", 5);

    cout << "Matricula: "<< a.obtemMatricula() << endl;
    cout << "Combustivel: "<< a.obtemCombustivel()<< endl;
    cout << "Marca: "<< a.obtemMarca()<< endl;
    cout << "Portas: "<< a.obtemPortas()<< endl;
    cout << "Velocidade: " << a.obtemVelociade(1,5);

    return 0;
}
