//
// Created by inesr on 02/11/2024.
//

#ifndef AUTOMOVEL_AUTOMOVEL_H
#define AUTOMOVEL_AUTOMOVEL_H

#include <string>
#include <sstream>

using namespace std;


class Automovel {
    string matricula;
    string combustivel;
    string marca;
    int num_portas;
    float dist;
    float tempo;

public:
    Automovel(string matricula, string combustivel, string marca, int num_portas);  //contrutor

    string obtemMatricula() const;

    string obtemCombustivel();

    string obtemMarca();

    int obtemPortas();

    float obtemVelociade (float dist, float tempo);

};


#endif //AUTOMOVEL_AUTOMOVEL_H
