//
// Created by inesr on 02/11/2024.
//

#include "Automovel.h"
#include <string>
using namespace std;

Automovel::Automovel(string matricula, string combustivel, string marca, int num_portas) : matricula(matricula), combustivel(combustivel), marca(marca), num_portas(num_portas) {}

string Automovel::obtemMatricula () const{
    return matricula;
}

string Automovel::obtemCombustivel(){
    return combustivel;
}

string Automovel::obtemMarca(){
    return marca;
}

int Automovel::obtemPortas(){
    return num_portas;
}

float Automovel::obtemVelociade(float distancia, float tempo){
    return distancia/tempo;
}

