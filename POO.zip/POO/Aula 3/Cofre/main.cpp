#include <iostream>

#include "Cofre.h"
#include <string>

using namespace std;

int main() {

    Cofre cofre (1234, 12345678);

    cout << "Abrir cofre: " << cofre.abrir(45) << endl;
    cout << "Abrir cofre: " << cofre.abrir(45) << endl;
    cout << "Abrir cofre: " << cofre.abrir(1234) << endl;
    cout << "Desbloquear cofre: " << cofre.desbloquear(12345678) << endl;
    cout << "Fechar cofre: " << cofre.fechar() << endl;
    cout << "Abrir cofre: " << cofre.abrir(45) << endl;
    cout << "Abrir cofre: " << cofre.abrir(45) << endl;
    cout << "Abrir cofre: " << cofre.abrir(45) << endl;
    cout << "Desbloquear cofre: " << cofre.desbloquear(12345678) << endl;
    cout << "Abrir cofre: " << cofre.abrir(1234) << endl;
    cout << "Adicionado item: " << cofre.adicionaItem("anel") << endl;
    cout << "Removido item: " << cofre.removoItem("pal") << endl;
    cout << "Adicionado item: " << cofre.adicionaItem("anel") << endl;
    cout << "Adicionado item: " << cofre.adicionaItem("colar") << endl;
    cout << "Adicionado item: " << cofre.adicionaItem("brinco") << endl;
    cout << cofre.listaItens() << endl;
    cout << "Removido item: " << cofre.removoItem("colar") << endl;
    cout << cofre.listaItens() << endl;
    cout << "Codigo alterado: " << cofre.alteraCodigo(1545,4321);

    return 0;
}
