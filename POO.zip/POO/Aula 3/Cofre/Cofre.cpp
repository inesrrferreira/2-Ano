//
// Created by inesr on 03/11/2024.
//

#include "Cofre.h"
#include <string>

using namespace std;

Cofre:: Cofre (int codigo, const int cod_desbl): codigo(codigo), cod_desbl(cod_desbl) {
    this->codigo = codigo;
    this->cod_desbl = cod_desbl;
    this->codigoAtual = codigo;
    tentativas = 0;}

bool Cofre::abrir (int codigo){
    if (codigo!=this->codigo){
        tentativas++;
        if(tentativas>=3){
            bloqueado = true;
            tentativas = 0;
            fechado = true;
        }
        return false;
    }else {
        aberto = true;
        bloqueado = false;
        fechado = false;
        tentativas = 0;
        return true;
    }
}

bool Cofre:: fechar( ){
    if(aberto){
        aberto = false;
        fechado = true;
        return true;
    }else{
        aberto =false;
        fechado = true;
        return true;
    }
}

bool Cofre:: desbloquear (const int cod_desbl){
    if(bloqueado && fechado){
        if(this->cod_desbl==cod_desbl){
            bloqueado = false;
            aberto=true;
            fechado=false;
            return true;
        }
    }
    return false;
}

bool Cofre::adicionaItem (const string &item){
    if(!aberto || item.empty()){
        return false;
    }
    for(int i=0; i<MAX_ELEMENTOS; i++){
        if(elementos[i].empty()){
            elementos[i]=item;
            return true;
        }
    }
    return false;
}

bool Cofre::removoItem (const string &item){
    if(!aberto){
        return false;
    }
    for(int i=0; i<MAX_ELEMENTOS; i++){
        if(elementos[i]==item){
            for(int j=i; j<MAX_ELEMENTOS-1; j++) {
                elementos[j] = elementos[j + 1];
            }
            return true;
        }
    }
    return false;

}

string Cofre::listaItens() {
    string lista;

    for (int i = 0; i < MAX_ELEMENTOS; i++) {
        if (!elementos[i].empty()) {  // Só adiciona se o elemento não está vazio
            if (!lista.empty()) {
                lista += ", ";  // Adiciona vírgula antes de cada item, exceto o primeiro
            }
            lista += elementos[i];
        }
    }

    return lista; // Retorna a lista completa como string
}

bool Cofre::alteraCodigo (int codigoAtual, int novo_cogigo){
    if(aberto){
        if(this->codigo == codigoAtual){
            this->codigo=novo_cogigo;
            return true;
        }
        return false;
    }
    return false;
}


