//
// Created by inesr on 03/11/2024.
//

#ifndef COFRE_COFRE_H
#define COFRE_COFRE_H
#include <string>

using namespace std;
#define MAX_ELEMENTOS 20


class Cofre {
    bool aberto, fechado;
    bool bloqueado;
    int codigo, codigoAtual;
    int tentativas;
    bool desbloqueado;
    int cod_desbl;
    string item;
    string elementos [MAX_ELEMENTOS];


public:
    Cofre(int codigo, const int cod_desbl);

    bool abrir (int codigo);
    bool fechar ();
    bool desbloquear (const int cod_desbl);
    bool adicionaItem (const string &item);
    bool removoItem (const string &item);
    string listaItens ();
    bool alteraCodigo (int codigoAtual, int novo_cogigo);

};


#endif //COFRE_COFRE_H
