//
// Created by inesr on 03/11/2024.
//

#include "Pessoa.h"
#include <sstream>
#include <string>
using namespace std;

Pessoa::Pessoa(string nome, int idade, int nif, float altura, float peso):nome(nome), idade(idade), nif(nif), altura(altura), peso(peso) {}

string Pessoa::obtemNome() const{
    return nome;
}
int Pessoa::obtemIdade (){
    return idade;
}
int Pessoa::obtemNif() const{
    return nif;
}
float Pessoa::obtemAltura(){
    return altura;
}
float Pessoa::obtemPeso(){
    return peso;
}
float Pessoa::obtemImc(float altura, float peso) {
    return (peso/(altura*2));

}