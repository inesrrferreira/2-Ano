#include <iostream>
#include "Pessoa.h"

using namespace std;

int main() {

    Pessoa p ("Ines", 26, 24568741, 1.61, 53.5);

    cout << "Nome: " << p.obtemNome() << endl;
    cout << "Idade: " << p.obtemIdade() << endl;
    cout << "NIF:" << p.obtemNif() << endl;
    cout << "Altura: " << p.obtemAltura() << endl;
    cout << "Peso: " << p.obtemPeso() << endl;
    cout << "IMC: " << p.obtemImc(p.obtemAltura(), p.obtemPeso()) << endl;



    return 0;
}
