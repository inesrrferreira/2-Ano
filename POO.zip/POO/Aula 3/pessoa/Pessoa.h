//
// Created by inesr on 03/11/2024.
//

#ifndef PESSOA_PESSOA_H
#define PESSOA_PESSOA_H
#include<string>


using namespace std;

class Pessoa {
    string nome;
    int idade;
    int nif;
    float altura;
    float peso;
    float imc;

public:
    Pessoa (string nome, int idade, int nif, float altura, float peso);

    string obtemNome() const;
    int obtemIdade ();
    int obtemNif() const;
    float obtemAltura();
    float obtemPeso();
    float obtemImc (float altura, float peso);

};


#endif //PESSOA_PESSOA_H
