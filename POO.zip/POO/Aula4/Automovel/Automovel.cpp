//
// Created by inesr on 03/11/2024.
//

#include "Automovel.h"
#include <iostream>

int Automovel::contador = 0;  // Inicialização do contador estático

// Construtor principal
Automovel::Automovel(string matricula, int num_portas, string marca, string cor)
        : matricula(matricula), num_portas(num_portas), marca(marca), cor(cor) {
    contador++;  // Incrementa o contador ao criar um novo objeto
}

// Construtor de cópia que também incrementa o contador
Automovel::Automovel(const Automovel& outro)
        : matricula(outro.matricula), num_portas(outro.num_portas), marca(outro.marca), cor(outro.cor) {
    contador++;  // Incrementa o contador ao copiar um objeto
}

// Destrutor que decrementa o contador ao destruir um objeto
Automovel::~Automovel() {
    contador--;  // Decrementa o contador ao destruir um objeto
}

// Métodos de acesso
string Automovel::obtemMatricula() const {
    return matricula;
}

int Automovel::obtemPortas() const {
    return num_portas;
}

string Automovel::obtemMarca() const {
    return marca;
}

string Automovel::obtemCor() const {
    return cor;
}

// Operador de atribuição
Automovel& Automovel::operator=(const Automovel &outro) {
    if (this != &outro) {        // Verifica auto-atribuição
        marca = outro.marca;     // Copia a marca
        cor = outro.cor;         // Copia a cor
        // A matrícula permanece imutável
    }
    return *this;
}

// Função para testar passagem por cópia (invoca o construtor de cópia)
void copia(Automovel a) {
    cout << "Copia de automovel: " << a.obtemMatricula() << " " << a.obtemPortas()
         << " " << a.obtemMarca() << " " << a.obtemCor() << endl;
}






