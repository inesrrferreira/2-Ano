//
// Created by inesr on 03/11/2024.
//

#ifndef AUTOMOVEL_AUTOMOVEL_H
#define AUTOMOVEL_AUTOMOVEL_H
#include<string>
#include <sstream>
#include <iostream>

using namespace std;

class Automovel {
    const string matricula;
    int num_portas;
    string marca;
    string cor;
    string novaCor;
    string novaMarca;
    static int contador;

public:
    Automovel(string matricula, int num_portas, string marca, string cor);

    // Construtor de cópia que também incrementa o contador
    Automovel(const Automovel& outro);

    // Destrutor (opcional para ajuste de contador, dependendo do uso)
    ~Automovel();

    string obtemMatricula () const;
    int obtemPortas () const;
    string obtemMarca() const;
    string obtemCor()const;



    Automovel& operator=(const Automovel &outro);

    static int getContador() {
        return contador;
    }

};

void copia(Automovel a);



#endif //AUTOMOVEL_AUTOMOVEL_H
