#include <iostream>
#include "Automovel.h"

using namespace std;

int main() {
    Automovel a("AE-00-MD", 5, "BMW", "Cinza");
    Automovel b("AP-00-MD", 5, "Citroen", "Vermelho");

    cout << "Carro 1: " << a.obtemMatricula() << " " << a.obtemPortas() << " "
         << a.obtemMarca() << " " << a.obtemCor() << endl;
    cout << "Carro 2: " << b.obtemMatricula() << " " << b.obtemPortas() << " "
         << b.obtemMarca() << " " << b.obtemCor() << endl;

    // Atribuição de 'a' para 'b' sem alterar a matrícula de 'b'
    b = a;
    cout << "Apos a atribuicao" << endl;
    cout << "Carro 1: " << a.obtemMatricula() << " " << a.obtemPortas() << " "
         << a.obtemMarca() << " " << a.obtemCor() << endl;
    cout << "Carro 2: " << b.obtemMatricula() << " " << b.obtemPortas() << " "
         << b.obtemMarca() << " " << b.obtemCor() << endl;

    // Teste da função que passa o automóvel por cópia
    cout << "Copia:" << endl;
    copia(a);

    // Exibe o número total de automóveis criados
    cout << "Total de automoveis criados: " << Automovel::getContador() << endl;

    return 0;
}

