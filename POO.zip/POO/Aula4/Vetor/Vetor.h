//
// Created by inesr on 03/11/2024.
//

#ifndef AULA4_VETOR_H
#define AULA4_VETOR_H
#include <string>
#include <cmath>

using namespace std;

class Vetor {
    double x;
    double y;

public:
    // Declaração dos construtores
    Vetor(double x, double y);
    Vetor(double value);
    Vetor();

    double getX() const;
    double getY() const;
    void setX(double novoX);
    void setY(double novoY);
    string toString() const;

    Vetor& operator=(const Vetor& a);
    Vetor& operator+=(const Vetor& a);
    Vetor& operator+=(double scalar);
    operator double() const {
        return sqrt(x * x + y * y);
    }

    Vetor operator++();
    Vetor operator++(int);

};

// Operadores globais
Vetor operator+(const Vetor& a, const Vetor& b);
Vetor operator+(double scalar, const Vetor& a);
Vetor operator+(const Vetor& a, double scalar);
Vetor operator-(const Vetor& a, const Vetor& b);
ostream& operator<<(ostream& outro, const Vetor& a);
bool operator==(const Vetor& a, const Vetor& b);
istream& operator >> (istream& input, Vetor &a);

#endif // AULA4_VETOR_H

