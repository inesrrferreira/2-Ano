//
// Created by inesr on 03/11/2024.
//

#include "Vetor.h"
#include <string>
#include <sstream>

using namespace std;

// Implementação dos construtores
Vetor::Vetor(double x, double y) : x(x), y(y) { }
Vetor::Vetor(double value) : x(value), y(value) { }
Vetor::Vetor() : x(0.0), y(0.0) { }

double Vetor::getX() const {
    return x;
}

double Vetor::getY() const {
    return y;
}

void Vetor::setX(double novoX) {
    x = novoX;
}

void Vetor::setY(double novoY) {
    y = novoY;
}

string Vetor::toString() const {
    ostringstream o;
    o << "(" << x << "," << y << ")";
    return o.str();
}

// Implementação do operador de atribuição
Vetor& Vetor::operator=(const Vetor& a) {
    x = a.getX();
    y = a.getY();
    return *this;
}

Vetor& Vetor::operator+=(const Vetor& a) {
    x += a.x;
    y += a.y;
    return *this;
}

Vetor& Vetor::operator+=(double scalar) {
    x += scalar;
    y += scalar;
    return *this;
}




// Implementação dos operadores globais
Vetor operator+(const Vetor& a, const Vetor& b) {
    return Vetor(a.getX() + b.getX(), a.getY() + b.getY());
}

Vetor operator+(double scalar, const Vetor& a) {
    return Vetor(a.getX() + scalar, a.getY() + scalar);
}

Vetor operator+(const Vetor& a, double scalar) {
    return Vetor(a.getX() + scalar, a.getY() + scalar);
}

Vetor operator-(const Vetor& a, const Vetor& b) {
    return Vetor(a.getX() - b.getX(), a.getY() - b.getY());
}

ostream& operator<<(ostream& outro, const Vetor& a) {
    outro << a.toString();
    return outro;
}

bool operator==(const Vetor& a, const Vetor& b) {
    return (a.getX() == b.getX() && a.getY() == b.getY());
}

Vetor Vetor::operator++() {
    ++x;
    ++y;
    return *this;
}
Vetor Vetor::operator++(int){
    x++;
    y++;
    return *this;
}

istream & operator >> (istream & input, Vetor &a){
    double x, y;
    x=a.getX();
    y=a.getY();
    input >> x >> y;
    return input;
}



