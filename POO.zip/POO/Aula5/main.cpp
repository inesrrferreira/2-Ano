#include <iostream>
#include <sstream>
#include <string>
#include "Roda.h"
#include "Automovel.h"

using namespace std;

int main() {
    // Criando um objeto da classe Automovel
    Automovel carro("Toyota", 150, 18);

    // Exibindo as informações do carro
    std::cout << "Marca: " << carro.obtemMarca() << "\n";
    std::cout << "Potência: " << carro.obtemPotencia() << " CV\n";
    std::cout << "Diâmetro das Rodas: " << carro.obtemDiametroRodas() << "\n";

    return 0;
}
