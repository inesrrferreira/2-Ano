//
// Created by inesr on 03/11/2024.
//

// Automovel.h
#ifndef AUTOMOVEL_H
#define AUTOMOVEL_H

#include <string>
#include "Roda.h"
using namespace std;

class Automovel {
    string marca;
    int potencia;
    Roda rodas[4];
    double diametroRodas;  // Certifique-se de que o nome é "diametroRodas"

public:
    Automovel(const string& marca, int potencia, double diametroRodas);

    string obtemMarca() const;
    int obtemPotencia() const;
    double obtemDiametroRodas() const;
};

#endif // AUTOMOVEL_H

