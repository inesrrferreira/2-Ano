//
// Created by inesr on 03/11/2024.
//

#include "Automovel.h"
#include <sstream>


using namespace std;


Automovel::Automovel(const std::string& marca, int potencia, double diametroRodas)
        : marca(marca), potencia(potencia), diametroRodas(diametroRodas),
          roda1(diametroRodas), roda2(diametroRodas), roda3(diametroRodas), roda4(diametroRodas) {}


string Automovel::obtemMarca () const{
    return marca;
}
int Automovel::obtemPotencia () const{
    return potencia;

}
double Automovel:: obtemDiametroRodas () const {
    return diametroRodas;
}