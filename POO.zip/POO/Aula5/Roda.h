//
// Created by inesr on 03/11/2024.
//

#ifndef AULA5_RODA_H
#define AULA5_RODA_H
#include "Automovel.h"

using namespace std;


class Roda {

    double diametro;
public:
    Roda(double d) : diametro (d > 1 && d < 30? : d : 21) {}

    double obtemDiametro() const { return diametro; }

};



#endif //AULA5_RODA_H
