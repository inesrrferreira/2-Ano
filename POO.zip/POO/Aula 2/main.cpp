#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class Tabela{

    static const int dim = 5;
    int matriz[dim];

public:

    Tabela() { initTabela(1); }; //construtor


    void initTabela(int a);
    void mostratab ();
   // int valor(const int indice);
    //void atualiza (int indice, int num);

    int alined (int indice, int valor);


};


void Tabela::initTabela(int a) {
    for (int i=0; i<dim; i++){
        matriz[i]=a;
    }
}

void Tabela::mostratab(){
    for (int i =0; i < dim;i++){
        cout << matriz[i] << " ";
    }
}

//int Tabela::valor( const int indice) {
//    if(indice < 0 || indice > dim-1) throw (0);
//    return matriz[indice];
//}
//
//void Tabela::atualiza(int indice, int num) {
//    for(int i = 0; i<dim; i++){
//        if(i==indice){
//            matriz[i] = num;
//            break;
//        }
//    }
//}

int Tabela::alined(int indice, int valor) {

    for(int i =0; i< dim; i++){
        if (i == indice){
            matriz[i] = valor;
        }
    }
    return matriz[indice];

}


int main () {

    Tabela x;

    try{
    //cout << endl << "Valor no indice: " << x.valor(1) << endl;
    //x.atualiza(2, 5);

    x.mostratab();

        cout << "Valor do indice: " << x.alined(2,10) << endl;
        x.mostratab();
} catch (int erro){
        cout <<"Indice invalido";
    }

}

//void troca (int &a, int &b){
//
//    int temp = a;
//    a=b;
//    b=temp;
//
//}
//
//int main(){
//    int a = 5, b = 10;
//    troca(a, b);
//    cout << "\na = " << a << "\nb = " << b;
//}

//
//int multiplica(int a=1, int b=1, int c=1){
//    return a*b*c;
//}
//
//int main() {
//
//    cout << "\n" << multiplica() << "\n" << multiplica(5);
//    cout << endl << multiplica(2, 3) << endl << multiplica(2, 3, 4);
//
//    return 0;
//}
