//
// Created by inesr on 07/11/2024.
//

#ifndef AULA6_PESSOA_H
#define AULA6_PESSOA_H
#include <string>
#include <sstream>


using namespace std;

class Pessoa {
public:
    Pessoa(const string & nome, int nBI, int nNIF)
            : nome(nome), BI(nBI), NIF(nNIF) {}

    string getNome() const { return nome; }
    int getNumeroBI() const { return BI; }
    int getNumeroNIF() const { return NIF; }
    void atualizarNome(const string& novoNome) {
        nome = novoNome;
    }



    string descricao() const {
        std::ostringstream oss;
        oss << "Nome: " << nome
            << ", BI: " << BI
            << ", NIF: " << NIF;
        return oss.str();
    }
private:
    string nome;
    int BI;
    int NIF;
};




//a) Composição


#endif //AULA6_PESSOA_H



//class Pessoa {
//public:
//    Pessoa(const string & nome, int nBI, int nNIF)
//            : nome(nome), BI(nBI), NIF(nNIF) {}
//
//    Pessoa(){BI=-1;}
//
//    string getNome() const { return nome; }
//    int getNumeroBI() const { return BI; }
//    int getNumeroNIF() const { return NIF; }
//    void atualizarNome(const string& novoNome) {
//        nome = novoNome;
//    }
//
//
//
//    string descricao() const {
//        std::ostringstream oss;
//        oss << "Nome: " << nome
//            << ", BI: " << BI
//            << ", NIF: " << NIF;
//        return oss.str();
//    }
//private:
//    string nome;
//    int BI;
//    int NIF;
//};
