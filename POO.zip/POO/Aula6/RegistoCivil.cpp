//
// Created by inesr on 07/11/2024.
//

#include "RegistoCivil.h"
#include <string>
#include <sstream>
#include "Pessoa.h"
#include <fstream>

using namespace std;


string RegistoCivil::getNomePais() const { return nome_pais; }

int RegistoCivil::getNumPessoa() const { return num_pessoas; }


void RegistoCivil::adicionaPessoa(const string &nome, int nBI, int nNIF) {
    Pessoa **temp = new Pessoa *[num_pessoas + 1];

    for (int i = 0; i < num_pessoas; i++) {
        temp[i] = pessoas[i];
    }

    temp[num_pessoas] = new Pessoa(nome, nBI, nNIF);
    delete[] pessoas;
    pessoas=temp;
    num_pessoas++;
}

void RegistoCivil::removePessoa(const int bi) {

    Pessoa **temp = new Pessoa *[num_pessoas - 1];

    for (int i = 0; i < num_pessoas; i++) {
        if (pessoas[i]->getNumeroBI() != bi) {
            temp[i] = pessoas[i];
        }else{
            delete pessoas[i];
        }
    }
    delete []pessoas;
    pessoas=temp;
    num_pessoas--;

}

string RegistoCivil::toString() const {
    ostringstream buffer;

    for (int i = 0; i < num_pessoas; i++) {
        buffer << "Nome: " << pessoas[i]->getNome() << " "<< "BI: " << pessoas[i]->getNumeroBI() << " " << "NIF: " << pessoas[i]->getNumeroNIF() << '\n';
    }

    return buffer.str();

}

void RegistoCivil::setNomePessoa (int bi, string novoNome){
    for (int i=0; i<num_pessoas; i++ ){
        if(pessoas[i]->getNumeroBI() == bi){
            pessoas[i]->atualizarNome(novoNome);
        }
    }
}

RegistoCivil::~RegistoCivil(){
    for(int i=0; i<num_pessoas; i++){
        delete pessoas[i];
    }
    delete[] pessoas;
}

string RegistoCivil::getNomePessoa (int bi) const{
    for (int i=0; i<num_pessoas; i++){
        if(pessoas[i]->getNumeroBI()==bi){
            return pessoas[i]->getNome();
        }
    }
    throw(404);

}

//copia
RegistoCivil::RegistoCivil(const RegistoCivil & outro){
    pessoas =new Pessoa * [outro.num_pessoas]; //duplica o array
    for(int i=0; i<num_pessoas; i++){
        pessoas[i] = new Pessoa(*outro.pessoas[i]);
    }
    num_pessoas = outro.num_pessoas;
    nome_pais=outro.nome_pais;
}

RegistoCivil & RegistoCivil::operator = (RegistoCivil outro){   //o outro nao vai ser por & porque o construtor por copia
    swap(*this, outro);
    return *this;
}

//bool RegistoCivil::lePessoas (const string & teste){
//
//    ifstream file(teste);
//
//    if(!file.is_open()){
//        return false;
//    }
//
//    string nome;
//    int bi, nif;
//    RegistoCivil temp(this->nome_pais);
//
//    while(file >> nome >> bi >> nif){
//        temp.adicionaPessoa(nome, bi, nif);
//    }
//
//    file.close();
//    swap(*this, temp);
//    return true;
//
//}
//
void swap(RegistoCivil &a, RegistoCivil & b){
   using std::swap;

    swap(a.nome_pais, b.nome_pais);
    swap(a.num_pessoas, b.num_pessoas);
    swap(a.pessoas, b.pessoas);
}


