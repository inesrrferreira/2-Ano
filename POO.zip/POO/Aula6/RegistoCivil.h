//
// Created by inesr on 07/11/2024.
//

#ifndef AULA6_REGISTOCIVIL_H
#define AULA6_REGISTOCIVIL_H
#include <string>
#include <sstream>
#include "Pessoa.h"
using namespace std;


class RegistoCivil{

    string nome_pais;
    int num_pessoas;
    Pessoa ** pessoas;

public:
    RegistoCivil(const string n) : nome_pais(n), num_pessoas(0), pessoas (nullptr) {
    }

    ~RegistoCivil();

    //copia
    RegistoCivil(const RegistoCivil & outro);

    string getNomePais () const;

    int getNumPessoa () const;

    void adicionaPessoa (const string & nome, int nBI, int nNIF);       //Cria a pessoa dentro do resgistoCivil; nao se faz void adicionaPessoa(Pessoa p){}

    void removePessoa(const int bi);

    string toString () const;

    string getNomePessoa (int bi) const;

    void setNomePessoa (int bi, string novoNome);

    bool lePessoas (const string & teste);

    RegistoCivil & operator = (RegistoCivil outro);

    friend void swap(RegistoCivil &a, RegistoCivil & b);


};

void swap(RegistoCivil & a, RegistoCivil & b)



#endif //AULA6_REGISTOCIVIL_H
