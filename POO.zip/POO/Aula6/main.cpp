#include <iostream>

#include "Pessoa.h"
#include "RegistoCivil.h"

using namespace std;

int main() {

    Pessoa p("Ines", 123, 145);

    RegistoCivil a("Portugal");
    a.adicionaPessoa("Rui", 123, 145);
    a.adicionaPessoa("Ines", 183, 888);
    a.adicionaPessoa("Guida", 688, 876);
    cout << a.toString();
    a.removePessoa(183);
    cout << "Removido" << endl;
    cout << a.toString();
    a.setNomePessoa(123, "Maria");
    cout << "Nome atualizado" << endl;
    cout << a.toString();






    return 0;
}
