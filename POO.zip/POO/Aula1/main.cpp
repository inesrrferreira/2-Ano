#include <iostream>
#include <string>
#include <sstream>
#include <fstream>


using namespace std;

string contra (string &palavra){
    string temp;


    for(int i=palavra.size()-1; i>=0; i--){
        temp+=palavra[i];

    }
    return temp;
}

void espera (){
    cin.ignore(1000, '\n');
    cout << "Carregue em enter para continuar...";
    cin.ignore(1000, '\n');
}

int main (){

    string pal, invertida;


        while(pal != "fim") {
            cout << "Palavra: ";
            cin >> pal;

            if (pal != "fim") {
                invertida = contra(pal);
                cout << "Palavra ao contrio: " << invertida << endl;

                if (pal == invertida) {
                    cout << "CAPICUA!" << endl;
                } else {
                    cout << "NAO CAPICUA" << endl;
                }

                espera();
            }
        }





    return 0;
}

//void compara(const string &nome){
//
//    if(nome == "Fernando") {
//        cout << "Conheco nome!!" << endl;
//    }
//
//}
//
//void separa(const string &nomeCompleto) {
//    istringstream tudo(nomeCompleto);  // Cria o stream de entrada a partir da string
//    string nome;
//
//    while (tudo >> nome) {  // Extrai cada palavra (nome) separada por espaços
//        compara(nome);     // Verifica se o nome é "Fernando"
//        cout << nome << endl;  // Imprime o nome em uma linha
//    }
//}
//
//int main (){
//
//    string nome;
//    int idade;
//
//    cout << "Insere nome: ";
//    getline(cin, nome);
//
//
//    while (true){
//        cout << "Introduz idade: ";
//        cin >> idade;
//        if(!cin >>idade){
//            cin.clear ();
//            cin.ignore(100, '\n');
//            continue;
//        }
//        if(idade<=0){
//            continue;
//        }
//        break;
//
//    }
//
//    cout << "Nome: " << nome << endl;
//    cout << "idade: " << idade <<endl;
//
//    cout << "Caracteres de nome: " << nome.size() << endl;
//    cout << "Nome por linha" << endl;
//
////    for(int i=0; i<nome.size(); i++){
////        cout << nome[i] << endl;
////    }
//
//    separa(nome);
//
//for(char n : nome){
//    cout << n << endl;
//}
//
//    return 0;
//}

//int main() {
//
//    char nome [10];
//    int idade;
//
//    cout << "Insere nome: ";
//    cin.getline (nome, 10);
//
//    while (true) {
//        cout << "\nIntroduz idade\n";
//        if(!(cin >> idade) ){  //verifica logo e guarda
//            cout << "Erro: Por favor, insira um valor inteiro positivo para a idade.\n";
//            cin.clear();
//            cin.ignore(100, '\n');
//            continue;
//        }
//        if (idade <=0){
//            continue;
//        }
//        break;
//    }
//
//
//    cout << "O teu nome e " << nome << endl;
//    cout << "Idade: " << idade << endl;
//
//    return 0;
//}
